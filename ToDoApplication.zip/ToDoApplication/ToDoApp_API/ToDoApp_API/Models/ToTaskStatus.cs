﻿namespace ToDoApp_API.Models
{
    public enum ToTaskStatus
    {
        NotStarted,
        InProgress,
        Completed
    }
}

