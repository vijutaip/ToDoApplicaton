import React, { useState, useEffect } from "react";
import { TaskStatus } from "../Status";

export default function TaskForm({ addTask, updateTask, editingTask, setEditingTask }) {
  const [name, setName] = useState("");
  const [priority, setPriority] = useState(1);
  const [status, setStatus] = useState(0);

  useEffect(() => {
    if (editingTask) {
      setName(editingTask.name);
      setPriority(editingTask.priority);
      setStatus(editingTask.status);
    }
  }, [editingTask]);

  const handleSubmit = (e) => {
    e.preventDefault();
    const trimmedName = name.trim();

    if (!trimmedName) {
      alert("Task name is required");
      return;
    }

     const nameRegex = /^[a-zA-Z0-9 ]+$/;
    if (!nameRegex.test(trimmedName)) {
      alert("Task name cannot contain special characters");
      return;
    }

       if (priority === "" || isNaN(priority)) {
      alert("Priority must be a number between 1 and 100");
      return;
    }

    const intPriority = parseInt(priority, 10);

    if (intPriority < 1 || intPriority > 100) {
      alert("Priority must be between 1 and 100");
      return;
    }

    const taskData = {
      name: trimmedName,
      priority: intPriority,
      status: parseInt(status)
    };

    if (editingTask) {
      updateTask(editingTask.id, taskData);
      setEditingTask(null);
    } else {
      addTask(taskData);
    }

    setName("");
    setPriority(1);
    setStatus(0);
  };

  return (
    <form onSubmit={handleSubmit} className="task-form">
      <input
        type="text"
        placeholder="Enter task name"
        value={name}
        onChange={(e) => setName(e.target.value)}
      />
      <input
        type="number"
        placeholder="Priority"
        value={priority}
        onChange={(e) => setPriority(e.target.value)}
        min="1"
      />
      <select value={status} onChange={(e) => setStatus(e.target.value)}>
        {Object.entries(TaskStatus).map(([key, value]) => (
          <option key={key} value={key}>{value}</option>
        ))}
      </select>
      <button type="submit">{editingTask ? "Update" : "Add"} Task</button>
      {editingTask && (
        <button type="button" onClick={() => setEditingTask(null)}>Cancel</button>
      )}
    </form>
  );
}