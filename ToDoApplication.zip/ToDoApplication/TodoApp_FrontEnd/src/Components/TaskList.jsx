import React from "react";
import { TaskStatus } from "../Status";

export default function TaskList({ tasks, setEditingTask, deleteTask }) {
  return (
    <table className="task-table">
      <thead>
        <tr>
          <th>Name</th>
          <th>Priority</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        {tasks.length > 0 ? (
          tasks.map((task) => (
            <tr key={task.id}>
              <td>{task.name}</td>
              <td>{task.priority}</td>
              <td>{TaskStatus[task.status]}</td>
              <td>
                <button onClick={() => setEditingTask(task)}>Edit</button>
                <button onClick={() => deleteTask(task.id)}>Delete</button>
              </td>
            </tr>
          ))
        ) : (
          <tr>
            <td colSpan="4" style={{ textAlign: "center" }}>No tasks found</td>
          </tr>
        )}
      </tbody>
    </table>
  );
}