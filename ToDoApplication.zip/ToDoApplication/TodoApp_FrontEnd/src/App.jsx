import { useState, useEffect } from 'react';
import TaskForm from './Components/TaskForm';
import TaskList from './Components/TaskList';
import './App.css';

function App() {

     const [tasks, setTasks] = useState([]);
  const [editingTask, setEditingTask] = useState(null);
  const API_URL = "https://localhost:5001/api/task";

  // Fetch tasks
  const fetchTasks = async () => {
    const res = await fetch(API_URL);
    const data = await res.json();
    setTasks(data);
  };

  useEffect(() => {
    fetchTasks();
  }, []);

  // Add Task
  const addTask = async (task) => {
    const res = await fetch(API_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(task)
    });

    if (!res.ok) {
      const error = await res.text();
      alert(error);
      return;
    }
    await fetchTasks();
  };

  // Update Task
  const updateTask = async (id, updatedTask) => {
    const res = await fetch(`${API_URL}/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(updatedTask)
    });

    if (!res.ok) {
      const error = await res.text();
      alert(error);
      return;
    }
    await fetchTasks();
  };

  // Delete Task
 const deleteTask = async (id) => {
  const confirmDelete = window.confirm("Are you sure you want to delete this task?");
  
  if (!confirmDelete) {
    return; // User clicked "Cancel", so do nothing
  }

  const res = await fetch(`${API_URL}/${id}`, { method: "DELETE" });
  
  if (!res.ok) {
    const error = await res.text();
    alert(error);
    return;
  }

  alert("Task deleted successfully!");
  
  // Refresh task list after deletion
  fetchTasks();
};

  return (
    <div className="page-wrapper">
     <div className="table-container">
      <h1>TODO Application</h1>
      <TaskForm
        addTask={addTask}
        updateTask={updateTask}
        editingTask={editingTask}
        setEditingTask={setEditingTask}
      />
      <TaskList
        tasks={tasks}
        setEditingTask={setEditingTask}
        deleteTask={deleteTask}
      />
    </div>
    </div>
  );
}

export default App;
